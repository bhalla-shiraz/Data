import java.io.File;

import org.rosuda.JRI.Rengine;

import rcaller.RCaller;
import rcaller.RCode;

public class Temp {
 
    public static void main(String a[]) {
    	try {
    	      RCaller caller = new RCaller();
    	      caller.setRscriptExecutable("C:/Program Files/R/R-3.2.2/bin/Rscript");

    	      RCode code = new RCode();
    	      code.clear();

    	      double[] numbers = new double[]{1, 4, 3, 5, 6, 10};

    	      code.addDoubleArray("x", numbers);
//    	      File file = code.startPlot();
//    	      System.out.println("Plot will be saved to : " + file);
//    	      code.addRCode("plot.ts(x)");
//    	      code.endPlot();

    	      code.R_source("logistic.R");
    	      
    	      caller.setRCode(code);
    	      caller.runAndReturnResult("acc");
    	      double[] results = caller.getParser().getAsDoubleArray("acc");
    	      System.out.println("acc is " + results[0]);
    	      
    	      caller.getCranRepos();
    	      //code.showPlot(file);
    	    } catch (Exception e) {
    	     e.printStackTrace();
    	    }
	 
	    }
	}