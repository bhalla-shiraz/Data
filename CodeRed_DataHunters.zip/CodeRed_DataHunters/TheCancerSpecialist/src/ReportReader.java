/*
 * Read the scanned report of the patient.
 * The report can be entered by a Doctor or Patient himself 
 */

public class ReportReader {

	ReportReader(String reportPath){
	
		System.out.println("The report file is " + reportPath);
	}
	
	
	
}
