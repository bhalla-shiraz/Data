import javax.swing.JFrame;

public class GUI extends JFrame{
	
	public GUI()
	{
		
	}
	private void initComponents() 
	{
		setTitle("Disease Analyst");
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);
	}
	
	
}
